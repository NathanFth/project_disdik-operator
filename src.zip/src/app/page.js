export default function Home() {
  return (
    <div className="min-h-screen bg-blue-100 flex items-center justify-center">
      <h1 className="text-3xl font-bold text-blue-900">
        Halo Operator E-Plandisdik!
      </h1>
    </div>
  );
}
