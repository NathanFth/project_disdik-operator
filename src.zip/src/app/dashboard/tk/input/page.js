import DataInputForm from "../../../components/DataInputForm";

export default function TkInputPage() {
  return <DataInputForm schoolType="TK" />;
}
