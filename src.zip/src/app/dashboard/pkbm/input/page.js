import DataInputForm from "../../../components/DataInputForm";

export default function PkbmInputPage() {
  return <DataInputForm schoolType="PKBM" />;
}
