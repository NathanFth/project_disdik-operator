import DataInputForm from "../../../components/DataInputForm";

export default function PaudInputPage() {
  return <DataInputForm schoolType="PAUD" />;
}
