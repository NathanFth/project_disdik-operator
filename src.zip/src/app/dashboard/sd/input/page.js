import DataInputForm from '../../../components/DataInputForm';

export default function SdInputPage() {
  return <DataInputForm schoolType="SD" />;
}